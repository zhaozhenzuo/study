package com.tongbanjie.tz.match.core.concurrent;

/**
 * 快速处理类使用回调来处理业务时需要传入的业务回调<br/>
 * 业务方只需要查询业务数据，然后提交给快速处理器即可<br/>
 * 后续的业务结果汇总对于业务方是透明的<br/>
 * 
 * @author shenxiu
 *
 */
public interface QuickBizProcessCallbak<T/* 每个批次任务处理结果类型 */, R/* 最终汇总的结果类型 *> */> {
	/*
	 * 执行业务方法
	 */
	public void doBiz(QuickProcessByNotify<T/* 每个批次任务处理结果类型 */, R/* 最终汇总的结果类型 *> */> quickProcessByNotify);

}
