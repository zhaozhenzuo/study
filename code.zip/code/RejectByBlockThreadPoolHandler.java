package com.tongbanjie.tz.match.core.concurrent;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;

/**
 * 定义当jdk ThreadPool线程池提交任务时,队列满了时的拒绝策略<br/>
 * 这里当提交任务,队列满了的时候会阻塞提交任务的线程
 * 
 * @author shenxiu
 *
 */
public class RejectByBlockThreadPoolHandler implements RejectedExecutionHandler {

	private static final Logger logger = LoggerFactory.getLogger(RejectByBlockThreadPoolHandler.class);

	// 业务名称，用于打印错误日志时标识是哪个业务
	private String bizName;

	public RejectByBlockThreadPoolHandler(String bizName) {
		this.bizName = bizName;
	}

	@Override
	public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
		try {
			executor.getQueue().put(r);
		} catch (InterruptedException e) {
			logger.error("add task to queue err,biz:" + bizName + "task:" + JSON.toJSONString(r));
		}

	}
}
