package com.tongbanjie.tz.match.core.concurrent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.collections.CollectionUtils;

/**
 * 最终消费完成后的汇总结果
 * 
 * @author shenxiu
 *
 */
public class ConsumeSumTaskResult implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 记录总数
	 */
	private AtomicInteger allCount = new AtomicInteger(0);

	private Map<Integer /* 结果状态码 */, StatusValueInfo> resMap = new ConcurrentHashMap<Integer, StatusValueInfo>();

	public String getShowRes() {
		if (resMap == null || resMap.size() <= 0) {
			return "无记录";
		}

		StringBuilder builder = new StringBuilder(32);
		int count = 0;
		for (Entry<Integer, StatusValueInfo> entry : resMap.entrySet()) {
			if (count++ != 0) {
				builder.append(",");
			}

			StatusValueInfo statusValueInfo = entry.getValue();
			builder.append("状态:" + statusValueInfo.getDesc() + ",数量:" + statusValueInfo.getCount());
			if (!CollectionUtils.isEmpty(statusValueInfo.getInfoList())) {
				builder.append(",消息:" + statusValueInfo.getInfoList().toString());
			}
		}
		return builder.toString();
	}

	/**
	 * 加入元素到resMap<br/>
	 * 
	 * @param status
	 * @param statusDesc
	 * @param countParam
	 *            数量
	 * @param infoList
	 */
	public void addElementOfStatus(Integer status, String statusDesc, int countParam, List<String> infoList) {

		StatusValueInfo statusValueInfo = resMap.get(status);
		if (statusValueInfo == null) {
			statusValueInfo = new StatusValueInfo(statusDesc);
		}

		/**
		 * count加1
		 */
		int count = statusValueInfo.getCount() + countParam;
		statusValueInfo.setCount(count);

		/**
		 * info加入list
		 */
		if (!CollectionUtils.isEmpty(infoList)) {
			List<String> tempList = statusValueInfo.getInfoList();
			if (tempList == null) {
				tempList = new ArrayList<String>();
				statusValueInfo.setInfoList(tempList);
			}
			tempList.addAll(infoList);
		}

		/**
		 * 更新map
		 */
		resMap.put(status, statusValueInfo);
	}

	/**
	 * 返回结果map
	 * 
	 * @return
	 */
	public Map<Integer /* 结果状态码 */, StatusValueInfo> getResMap() {
		return resMap;
	}

	/**
	 * 对应状态码信息类
	 * 
	 * @author shenxiu
	 *
	 */
	public class StatusValueInfo {

		/**
		 * 该状态记录条数
		 */
		private int count;

		/**
		 * 对应状态码描述信息
		 */
		private String desc;

		/**
		 * 该状态对应元素值，一般只有失败才会将相应元素信息放入
		 */
		private List<String> infoList;

		/**
		 * 创建一个StatusValueInfo对象,count为0
		 * 
		 * @param desc
		 */
		public StatusValueInfo(String desc) {
			this.desc = desc;
			this.count = 0;
		}

		public int getCount() {
			return count;
		}

		public void setCount(int count) {
			this.count = count;
		}

		public String getDesc() {
			return desc;
		}

		public void setDesc(String desc) {
			this.desc = desc;
		}

		public List<String> getInfoList() {
			return infoList;
		}

		public void setInfoList(List<String> infoList) {
			this.infoList = infoList;
		}

	}

	public AtomicInteger getAllCount() {
		return allCount;
	}

	public void setAllCount(AtomicInteger allCount) {
		this.allCount = allCount;
	}

}
