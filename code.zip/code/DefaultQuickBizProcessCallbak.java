package com.tongbanjie.tz.match.core.concurrent;

/**
 * 默认处理回调抽象父类<br/>
 * 这里默认了每个任务的返回结果，及最终汇总结果
 * 
 * @author shenxiu
 *
 */
public abstract class DefaultQuickBizProcessCallbak implements QuickBizProcessCallbak<BizTaskResult, ConsumeSumTaskResult> {

}
