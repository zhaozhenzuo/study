package com.tongbanjie.tz.match.core.concurrent;

/**
 * 业务处理状态<br/>
 * 
 * @author shenxiu
 *
 */
public interface RiBizStatus {

	/**
	 * 未知状态,指被调用方代码异常或网络异常
	 */
	public static final String UNKNOW = "-2";

	/**
	 * 处理中
	 */
	public static final String PROCESSING = "2";

	/**
	 * 成功
	 */
	public static final String SUCCESS = "1";

	/**
	 * 失败
	 */
	public static final String FAILURE = "-1";

}
