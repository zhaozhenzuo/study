package com.tongbanjie.tz.match.core.concurrent;

import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorService;

/**
 * 默认快速并发处理器,方便开发人员使用，默认:<br/>
 * 单个任务处理结果对象为：BizTaskResult,最终汇总结果对象为:ConsumeSumTaskResult,默认结果处理类:DefaultTaskResultHandler
 * 
 * @author shenxiu
 *
 */
public class DefaultQuickProcessByNotity extends QuickProcessByNotify<BizTaskResult, ConsumeSumTaskResult> {

	public DefaultQuickProcessByNotity(CompletionService<BizTaskResult> quickCompletionService,
			QuickTaskResultHandler<BizTaskResult, ConsumeSumTaskResult> taskResultHandler) {
		super(quickCompletionService, taskResultHandler);
	}

	public DefaultQuickProcessByNotity(ExecutorService executorService) {
		super(executorService);
		/**
		 * 这里默认结果处理类
		 */
		super.addTaskResultHandler(new DefaultTaskResultHandler());
	}

}
