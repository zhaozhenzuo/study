package com.tongbanjie.tz.match.core.concurrent;

import java.util.concurrent.Callable;

public interface QuickProcessService<T/* 业务任务处理结果类型 */, R/* 最终汇总的结果类型 */> {

	/**
	 * 开启处理器,实现需要开启消费者线程
	 */
	public void start();

	/**
	 * 强制消费者停下来,有可能会造成数据处理不完整(看具体业务),慎用<br/>
	 * 调用此方法后，消费者不再处理任务，马上被停了
	 * 
	 */
	public void shutdownNow();

	/**
	 * 提交业务任务
	 * 
	 * @param task
	 */
	public void submit(Callable<T> task);

	/**
	 * 等于消费者处理结果<br/>
	 * 注： 这里的结果指最终汇总结果
	 * 
	 * @throws InterruptedException
	 */
	public void waitProcessResult() throws InterruptedException;

	/**
	 * 唤醒消费者处理【业务结果】
	 */
	public void notifyConsumer();

	/**
	 * 发送者发送完所有消息了,设置sendFinishFlag为true
	 */
	public void setSendFinishFlagToTrue();

	/**
	 * 返回最终汇总结果
	 * 
	 * @return
	 */
	public R getResult();

	/**
	 * 设置回调函数，处理业务<br/>
	 * bizProcessCallbak负责查业务数据，并提交给处理器中业务方设置的【处理业务任务线程池】
	 * 
	 * @param bizProcessCallbak
	 * @return 结果
	 */
	@SuppressWarnings("rawtypes")
	public R processByCallBack(QuickBizProcessCallbak bizProcessCallbak) throws InterruptedException;

}
