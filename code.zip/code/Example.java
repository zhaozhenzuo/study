package com.tongbanjie.tz.match.biz.job;

import com.alibaba.fastjson.JSON;
import com.tongbanjie.commons.component.RedisComponent;
import com.tongbanjie.commons.constants.BizStatus;
import com.tongbanjie.commons.lang.Result;
import com.tongbanjie.coupon.facade.constants.CouponType;
import com.tongbanjie.coupon.facade.interf.CouponQueryFacade;
import com.tongbanjie.coupon.facade.model.Coupon;
import com.tongbanjie.legends.client.core.AbstractJob;
import com.tongbanjie.pay.facade.consts.PayStatus;
import com.tongbanjie.pay.facade.consts.PayWay;
import com.tongbanjie.tongbao.facade.TbShareManageFacade;
import com.tongbanjie.tz.commons.constant.TzPlatformMerchantCode;
import com.tongbanjie.tz.match.biz.component.CouponComponent;
import com.tongbanjie.tz.match.biz.component.FrozenShareComponent;
import com.tongbanjie.tz.match.biz.component.model.CouponResult;
import com.tongbanjie.tz.match.biz.service.MatchResultService;
import com.tongbanjie.tz.match.biz.service.PreOrderService;
import com.tongbanjie.tz.match.biz.util.CheckTradeResult;
import com.tongbanjie.tz.match.biz.util.MatchResultUtil;
import com.tongbanjie.tz.match.biz.util.TongbaoUtil;
import com.tongbanjie.tz.match.core.SortColumn;
import com.tongbanjie.tz.match.core.concurrent.*;
import com.tongbanjie.tz.match.core.util.DateUtil;
import com.tongbanjie.tz.match.core.util.IPUtil;
import com.tongbanjie.tz.match.model.MatchResult;
import com.tongbanjie.tz.match.model.MatchResultDatas;
import com.tongbanjie.tz.match.model.PreOrder;
import com.tongbanjie.tz.match.model.enums.PreOrderStatusEnum;
import com.tongbanjie.tz.match.model.so.MatchResultSo;
import com.tongbanjie.tz.match.model.so.PreOrderSo;
import com.tongbanjie.tz.match.model.vo.PreOrderVo;
import com.tongbanjie.tz.order.facade.OrderQueryFacade;
import com.tongbanjie.tz.order.facade.constant.OrderStatus;
import com.tongbanjie.tz.order.facade.constant.OrderType;
import com.tongbanjie.tz.order.facade.constant.Seller;
import com.tongbanjie.tz.order.facade.model.Order;
import com.tongbanjie.tz.trade.facade.MatchTradeFacade;
import com.tongbanjie.tz.trade.facade.model.dto.OrderDTO;
import com.tongbanjie.tz.trade.facade.model.dto.OrderDetailDTO;
import com.tongbanjie.tz.trade.facade.model.request.MatchTradeRequst;
import com.tongbanjie.tz.trade.facade.model.response.MatchTradeResponse;
import com.tongbanjie.tzprod.facade.constants.ShareChangeSourceConstants;
import com.tongbanjie.tzprod.facade.mange.TzSubjectShareChangeMangeFacade;
import com.tongbanjie.tzprod.facade.request.TzSubjectShareChangeReq;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.StopWatch;
import org.javatuples.Pair;
import org.javatuples.Triplet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 匹配完成后加资产job
 * 
 * @author shenxiu
 *
 */
@Component
public class TzMatchBuyAndAddAssetJob extends AbstractJob {

	private static final Logger logger = LoggerFactory.getLogger(TzMatchBuyAndAddAssetJob.class);

	private static final ThreadPoolExecutor executorService = new ThreadPoolExecutor(1, 2, 60L, TimeUnit.SECONDS,
			new LinkedBlockingDeque<Runnable>(10000), new RejectByBlockThreadPoolHandler("buyAddAsset"));

	static {
		executorService.allowCoreThreadTimeOut(true);
	}

	@Autowired
	private PreOrderService preOrderService;

	@Autowired
	private RedisComponent redisComponent;

	@Autowired
	private MatchResultService matchResultService;

	@Autowired
	private MatchTradeFacade matchTradeFacade;

	@Autowired
	private OrderQueryFacade orderQueryFacade;

	@Autowired
	private TzSubjectShareChangeMangeFacade tzSubjectShareChangeMangeFacade;

	@Autowired
	private FrozenShareComponent frozenShareComponent;

	@Autowired
	private CouponComponent couponComponent;

	private static final String LOCK_KEY_FOR_JOB = "TzMatchAddAssetJob";

	private static final String LOCK_KEY_FOR_PRE_ORDER = "TzMatchAddAssetJob_PreOrder_";

	/**
	 * 3小时超时
	 */
	private static final int EXPIRE_TIME_FOR_JOB_MILLSECONDS = 3 * 3600 * 1000;

	/**
	 * 30分钟超时
	 */
	private static final int EXPIRE_TIME_FOR_PROCESS_PREORDER_MILLSECONDS = 30 * 1000;

	private static final int BATCH_SIZE = 1000;

	/**
	 * 默认往前查找预约单的时间
	 */
	private static final int DEFAULT_BEFORE_DAYS = 365;

	private static final String DATE_PARAM_SPLIT = ",";
	
	private static final String MATCH_FAIL_TITLE="撮合失败";

	/**
	 * 参数：<br/>
	 * 开始时间,结束时间<br/>
	 * eg:20161220,20170213
	 */
	@Override
	public String execute(String param) {
		logger.info(">begin exec TzMatchAddAssetJob,param[" + param + "]");

		String lockKey = this.getLockKey();
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		StringBuilder builder = new StringBuilder("执行预约单匹配");
		String ip = IPUtil.getHostIp();
		Date curDate = new Date();
		builder.append(",host[" + ip + "],日期[" + DateUtil.getDateAsInt(curDate) + "]");
		boolean lockFlag = false;
		try {

			/**
			 * 0.获取redis锁，防止job并发执行
			 */
			lockFlag = redisComponent.acquireLock(lockKey, EXPIRE_TIME_FOR_JOB_MILLSECONDS);
			if (!lockFlag) {
				logger.info(">end exec TzMatchAddAssetJob,并发执行,获取redis锁失败,param[" + param + "]");
				return "并发执行";
			}

			/**
			 * 1.处理加资产任务
			 */
			final DefaultQuickProcessByNotity quickProcessByNotify = new DefaultQuickProcessByNotity(executorService);
			ConsumeSumTaskResult processResult = quickProcessByNotify.processByCallBack(new BuyAndAssetTask(param));

			builder.append(",总条数[" + processResult.getAllCount() + "],info[" + processResult.getShowRes() + "]");
		} catch (InterruptedException e) {
			logger.error(">TzMatchAddAssetJob InterruptedException,", e);
			return "执行匹配加资产发生InterruptedException";
		} catch (Exception e) {
			logger.error(">end exec TzMatchAddAssetJob exception,param[" + param + "]", e);
			builder.append(",发生异常");
		} finally {
			if (lockFlag) {
				redisComponent.releaseLock(lockKey);
			}
		}

		String resStr = builder.toString();
		logger.info("end exec TzMatchAddAssetJob,param[" + param + "]," + resStr + "]");
		return resStr;
	}

	private Pair<Date/* 开始时间 */, Date/* 结束时间 */> parseParam(String param, Date curDate) {
		Date startCreateTime;
		Date endCreateTime;

		int curDateInt = DateUtil.getDateAsInt(curDate);
		Date curDateNoHMS = DateUtil.intDateToDate(curDateInt);

		if (StringUtils.isBlank(param)) {
			/**
			 * 默认查找前一年到今天为止的所有需要处理的预约单
			 */
			startCreateTime = DateUtil.addDays(curDateNoHMS, DEFAULT_BEFORE_DAYS * -1);
			endCreateTime = DateUtil.addDays(curDateNoHMS, 1);
		} else {
			/**
			 * 有参数时，解析参数
			 */
			String[] arr = param.split("\\" + DATE_PARAM_SPLIT);
			if (arr.length != 2) {
				throw new IllegalArgumentException("格式错误,开始时间,结束时间,eg:20161220,20170213");
			}

			startCreateTime = DateUtil.intDateToDate(Integer.valueOf(arr[0]));
			endCreateTime = DateUtil.intDateToDate(Integer.valueOf(arr[1]));
		}

		return new Pair<Date, Date>(startCreateTime, endCreateTime);
	}

	/**
	 * 调用trade购买加资产任务
	 * 
	 * @author shenxiu
	 *
	 */
	class BuyAndAssetTask implements QuickBizProcessCallbak<BizTaskResult, ConsumeSumTaskResult> {

		private String param;

		public BuyAndAssetTask(String param) {
			this.param = param;
		}

		@Override
		public void doBiz(QuickProcessByNotify<BizTaskResult, ConsumeSumTaskResult> quickProcessByNotify) {
			/**
			 * 1.处理预约单
			 */
			PreOrderSo so = composeSo(param);

			/**
			 * 2.查询预约单并处理
			 */
			int size = BATCH_SIZE;

			Set<String> processedPreOrderSet = new HashSet<String>(BATCH_SIZE);

			while (size == BATCH_SIZE) {
				/**
				 * 2.1.查询要处理的预约单
				 */
				List<PreOrder> preOrderList = preOrderService.searchPosBySo(so);
				if (CollectionUtils.isEmpty(preOrderList)) {
					break;
				}

				/**
				 * 2.2.处理这个批次的预约单
				 */
				for (PreOrder preOrder : preOrderList) {
					String preOrderNo = preOrder.getPreOrderNo();
					
					if(isTerminated()){
						logger.info(">user terminate tzMatchAddAssetJob");
						break;
					}
					
					if (processedPreOrderSet.contains(preOrderNo)) {
						/**
						 * 按时间查找有可能重复，最坏情况下，当前查找了一批，下次以这批最后一条记录为开始时间时<br/>
						 * 可能会把这条记录也查找出来，因此需要建立这个set，把重复的记录过滤
						 */
						continue;
					}
					processedPreOrderSet.add(preOrderNo);

					quickProcessByNotify.submit(new ProcessOnePreOrderTask(preOrder));
				}

				size = preOrderList.size();
				Date latestStartCreateTime = preOrderList.get(size - 1).getCreateTime();
				so.setStartCreateTime(latestStartCreateTime);
			}
		}
	}

	private PreOrderSo composeSo(String param) {
		PreOrderSo so = new PreOrderSo();
		so.setRows(BATCH_SIZE);

		List<Integer> statusList = Arrays.asList(PreOrderStatusEnum.MATCHED.getValue());
		so.setStatusList(statusList);

		List<SortColumn> sortList = Arrays.asList(new SortColumn("create_time", SortColumn.ASC));
		so.setSortList(sortList);

		Date curDate = new Date();
		Pair<Date/* 开始时间 */, Date/* 结束时间 */> datePair = parseParam(param, curDate);
		Date startCreateTime = datePair.getValue0();
		Date endCreateTime = datePair.getValue1();
		so.setStartCreateTime(startCreateTime);
		so.setEndCreateTime(endCreateTime);

		return so;
	}

	/**
	 * 处理单个预约单任务，会交给线程池做
	 * 
	 * @author shenxiu
	 *
	 */
	class ProcessOnePreOrderTask implements Callable<BizTaskResult> {

		private PreOrder preOrder;

		public ProcessOnePreOrderTask(PreOrder preOrder) {
			this.preOrder = preOrder;
		}

		@Override
		public BizTaskResult call() throws Exception {
			return processOnePreOrder(preOrder);
		}
	}

	/**
	 * 处理单个预约单<br/>
	 * 
	 * @param preOrder
	 * @return
	 */
	private BizTaskResult processOnePreOrder(final PreOrder preOrder) {
		String preOrderNo = preOrder.getPreOrderNo();
		logger.info(">begin processOnePreOrder,preOrderNo[" + preOrderNo + "]");

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		BizTaskResult bizTaskResult;
		boolean lockFlag = false;
		String lockKey = getProcesPreOrderKey(preOrderNo);
		Triplet<Boolean, Integer, String> resPair;

		try {

			/**
			 * 1.获取redis锁
			 */
			lockFlag = redisComponent.acquireLock(lockKey, EXPIRE_TIME_FOR_PROCESS_PREORDER_MILLSECONDS);
			if (!lockFlag) {
				logger.error(">processOnePreOrder并发,preOrderNo[" + preOrderNo + "]");
				bizTaskResult = new BizTaskResult(BizStatus.FAILURE, "并发执行", preOrderNo);
				return bizTaskResult;
			}

			/**
			 * 2.查看是否存在订单
			 */
			String type = OrderType.MATCH_PURCHASE;
			// TODO,目前销售商都是TBJ
			String seller = Seller.TBJ_SELLER;
			Order order = this.getOrderByPreOrderNo(preOrderNo, type, seller);
			if (order != null) {
				/**
				 * 有订单
				 */
				resPair = this.processHasExistOrder(preOrder, order);
			} else {
				/**
				 * 还没订单
				 */
				resPair = this.processHasNotExistOrder(preOrder);
			}
		} catch (Exception e) {
			logger.error(">processOnePreOrder exception,preOrderNo[" + preOrderNo + "]", e);
			resPair = new Triplet<Boolean, Integer, String>(false, null, "发生异常");
		} finally {
			if (lockFlag) {
				redisComponent.releaseLock(lockKey);
			}
		}

		/**
		 * 3.封装结果
		 */
		boolean finishFlag = resPair.getValue0();
		Integer preOrderStatusFinish = resPair.getValue1();
		String reason = resPair.getValue2();

		if (finishFlag) {
			/**
			 * 3.1.处理完成
			 */
			if (PreOrderStatusEnum.SUCCESS.getValue() == preOrderStatusFinish) {
				bizTaskResult = new BizTaskResult(BizStatus.SUCCESS, "预约成功", null);
			} else if (PreOrderStatusEnum.FAIL.getValue() == preOrderStatusFinish) {
				bizTaskResult = new BizTaskResult(BizStatus.FAILURE, "预约失败", null);
			} else {
				logger.error(">未知状态,preOrderNo[" + preOrderNo + "]");
				bizTaskResult = new BizTaskResult(BizStatus.UNKNOW, "已处理完成,返回的预约单状态未知", preOrderNo);
			}

		} else {
			/**
			 * 3.2.未处理完成
			 */
			bizTaskResult = new BizTaskResult(BizStatus.PROCESSING, reason, preOrderNo);
		}

		logger.info(">end processOnePreOrder,preOrderNo[" + preOrderNo + "],cost[" + stopWatch.getTime() + "],res["
				+ bizTaskResult.getBizStatus() + "],reason[" + bizTaskResult.getBizStatusDesc() + "]");

		return bizTaskResult;
	}

	/**
	 * 处理还没有订单的情况<br/>
	 * 需要调用trade的购买接口
	 * 
	 * @param preOrder
	 * @return
	 */
	private Triplet<Boolean/* 是否处理完成 */, Integer, String> processHasNotExistOrder(PreOrder preOrder) {
		/**
		 * 0.组装购买请求
		 */
		MatchTradeRequst buyRequst = this.composeBuyRequest(preOrder);

		/**
		 * 1.购买
		 */
		long oldTimeForBuy=System.currentTimeMillis();
		Result<MatchTradeResponse> buyResult = matchTradeFacade.buy(buyRequst);
		
		long costForBuy=System.currentTimeMillis()-oldTimeForBuy;
		logger.info(">cost for buy["+costForBuy+"]");
		
		if (buyResult == null || buyResult.getData() == null || !buyResult.isSuccess()) {
			return new Triplet<Boolean, Integer, String>(false, null, "trade返回异常");
		}

		MatchTradeResponse matchTradeResponse = buyResult.getData();
		int matchStatus = matchTradeResponse.getStatus();
		String preOrderNo = preOrder.getPreOrderNo();
		if (MatchTradeResponse.SUCCESS == matchStatus) {
			/**
			 * 成功,更新预约单为成功
			 */
			List<Integer> expectStatusList = Arrays.asList(PreOrderStatusEnum.MATCHED.getValue());
			boolean updateFlag = this.updatePreOrderStauts(preOrderNo, PreOrderStatusEnum.SUCCESS.getValue(), expectStatusList,
					PayStatus.SUCCESS, null,null);
			if (!updateFlag) {
				logger.error(">update preOrder to succ fail in processHasNoOrder,preOrderNo[" + preOrderNo + "]");
				return new Triplet<Boolean, Integer, String>(false, null, "订单已成功,更新预约单状态为【预约成功】失败");
			}
			return new Triplet<Boolean, Integer, String>(true, PreOrderStatusEnum.SUCCESS.getValue(), null);
		} else if (MatchTradeResponse.FAILED == matchStatus) {
			/**
			 * 失败,这里暂不处理，下次处理根据订单状态来做相应处理
			 */
			return new Triplet<Boolean, Integer, String>(false, null, "trade返回失败,下次处理");
		} else {
			/**
			 * 其它未知情况
			 */
			return new Triplet<Boolean, Integer, String>(false, null, "trade返回未知状态");
		}

	}

	/**
	 * 处理已经存在订单的情况<br/>
	 * 看订单状态是否是成功或失败，成功则将预约单更改成【预约成功】，否则需要回滚标的份额及解冻铜宝
	 * 
	 * @param preOrder
	 * @param order
	 * @return
	 */
	private Triplet<Boolean/* 是否处理完成 */, Integer/* 最后预约单状态 */, String/* 失败原因 */> processHasExistOrder(PreOrder preOrder, Order order) {
		Assert.notNull(order);

		String preOrderNo = preOrder.getPreOrderNo();
		int orderStatus = order.getStatus();
		if (OrderStatus.BUY_SUECCESS == orderStatus) {
			/**
			 * 订单成功
			 */
			List<Integer> expectStatusList = Arrays.asList(PreOrderStatusEnum.MATCHED.getValue());
			boolean updateFlag = this.updatePreOrderStauts(preOrderNo, PreOrderStatusEnum.SUCCESS.getValue(), expectStatusList,
					PayStatus.SUCCESS, null,null);
			if (!updateFlag) {
				logger.error(">update preOrder to succ fail,preOrderNo[" + preOrderNo + "]");
				return new Triplet<Boolean, Integer, String>(false, null, "订单存在,订单已成功,更新预约单状态为【预约成功】失败");
			}

			return new Triplet<Boolean, Integer, String>(true, PreOrderStatusEnum.SUCCESS.getValue(), null);
		} else if (OrderStatus.BUY_FAILURE == orderStatus) {
			/**
			 * 订单失败
			 * 回滚产品份额,铜宝份额
			 */
			boolean rollbackFlg = this.rollback(preOrder, order);
			if (!rollbackFlg) {
				logger.error(">rollback fail,preOrderNo[" + preOrderNo + "]");
				return new Triplet<Boolean, Integer, String>(false, null, "回滚失败");
			}

			/**
			 * 回滚成功后,更新预约单状态为[预约失败]
			 */
			List<Integer> expectStatusList = Arrays.asList(PreOrderStatusEnum.MATCHED.getValue());
			boolean updateFlag = this.updatePreOrderStauts(preOrderNo, PreOrderStatusEnum.FAIL.getValue(), expectStatusList,
					PayStatus.FAILURE, null,MATCH_FAIL_TITLE);
			if (!updateFlag) {
				logger.error(">update preOrder to succ fail,preOrderNo[" + preOrderNo + "]");
				return new Triplet<Boolean, Integer, String>(false, null, "订单存在,订单已失败,更新预约单状态为【预约失败】失败");
			}

			return new Triplet<Boolean, Integer, String>(true, PreOrderStatusEnum.FAIL.getValue(), null);
		} else {
			return new Triplet<Boolean, Integer, String>(false, null, "订单存在,订单状态还没有成为终态");
		}

	}

	/**
	 * 回滚产品份额，铜宝份额
	 * 
	 * @param preOrder
	 * @return
	 */
	private boolean rollback(PreOrder preOrder, Order order) {
		/**
		 * 0.检查
		 */
		Assert.notNull(preOrder, "预约单不能为空");
		Assert.notNull(preOrder.getPreOrderNo(), "预约单号不能为空");
		Assert.notNull(order, "订单不能为空");
		Assert.hasText(order.getOrderNo(), "订单号不能为空");
		Assert.isTrue(OrderStatus.BUY_FAILURE == order.getStatus(), "订单状态不是【失败】不能回滚");

		/**
		 * 0.回滚卡券
		 */
        Long deductCouponId = preOrder.getDeductCouponId();
        if(deductCouponId != null){
            CouponResult couponResult = couponComponent.rollBackDoSpendCoupon(deductCouponId, CouponType.DEDUCT, preOrder);
            if(!couponResult.isSucc()){
                logger.error("> tz-trade层返回订单 失败，回滚卡券异常，preOrderNo：{}，couponId:{}",preOrder.getPreOrderNo(),deductCouponId);
                return false;
            }
        }

        /**
		 * 1.回滚产品份额
		 */
		boolean rollbackProductShareRes = this.rollbackProductShare(preOrder);
		if (!rollbackProductShareRes) {
			/**
			 * 回滚失败，下回处理
			 */
			return false;
		}

		/**
		 * 2.回滚铜宝
		 */

		boolean rollbackTongbaoRes = frozenShareComponent.rollbackShare(preOrder, order);
		if (!rollbackTongbaoRes) {
			return false;
		}

		return true;
	}

	/**
	 * 回滚产品份额
	 * 
	 * @param preOrder
	 * @return 是否回滚成功
	 */
	private boolean rollbackProductShare(PreOrder preOrder) {
		/**
		 * 0.是否扣过
		 */
		String preOrderNo = preOrder.getPreOrderNo();
		TzSubjectShareChangeReq shareChangeQueryReq = this.composeIsBuckleProductShareReq(preOrder);
		Result<Boolean> shareChangeResult = tzSubjectShareChangeMangeFacade.isBuckled(shareChangeQueryReq);
		if (!shareChangeResult.isSuccess()) {
			/**
			 * 发生异常，下次处理
			 */
			logger.error(">invoke isBuckled err,preOrderNo[" + preOrderNo + "]");
			return false;
		}

		if (!shareChangeResult.getData()) {
			/**
			 * 没有扣过，不需要走下面的回滚流程
			 */
			return true;
		}

		/**
		 * 1.回滚产品份额
		 */
		/**
		 * 1.1.组装回滚参数
		 */
		TzSubjectShareChangeReq rollbackReq = this.composeRollbackProductShareReq(preOrder);

		/**
		 * 1.2.回滚
		 */
		Result<Boolean> rollbackResFlag = tzSubjectShareChangeMangeFacade.rollbackBuckle(rollbackReq);
		if (!rollbackResFlag.isSuccess() || rollbackResFlag.getData() == null) {
			logger.error(">调用rollbackBuckle,返回isSucc为false,preOrderNo[" + preOrderNo + "],res[" + JSON.toJSONString(rollbackResFlag) + "]");
			return false;
		}

		if (rollbackResFlag.getData()) {
			/**
			 * 回滚成功
			 */
			return true;
		} else {
			/**
			 * 回滚失败
			 */
			return false;
		}

	}

	private TzSubjectShareChangeReq composeRollbackProductShareReq(PreOrder preOrder) {
		String preOrderNo = preOrder.getPreOrderNo();
		BigDecimal amount = preOrder.getOriginalAmount();

		TzSubjectShareChangeReq shareChangeReq = new TzSubjectShareChangeReq();
		shareChangeReq.setSeqId(preOrderNo);
		shareChangeReq.setChangeAmount(amount);
		shareChangeReq.setPlatformMerchantCode(TzPlatformMerchantCode.TZ_PLATFORM_MERCHANT_CODE);
		shareChangeReq.setSource(ShareChangeSourceConstants.SUBJECT_MATCH_SOURCE);
		shareChangeReq.setProductId(Long.valueOf(preOrder.getProductId()));
		shareChangeReq.setUserId(preOrder.getUserId());

		return shareChangeReq;
	}

	private TzSubjectShareChangeReq composeIsBuckleProductShareReq(PreOrder preOrder) {
		String preOrderNo = preOrder.getPreOrderNo();

		TzSubjectShareChangeReq shareChangeReq = new TzSubjectShareChangeReq();
		shareChangeReq.setSeqId(preOrderNo);
		shareChangeReq.setSource(ShareChangeSourceConstants.SUBJECT_MATCH_SOURCE);
		shareChangeReq.setProductId(Long.valueOf(preOrder.getProductId()));
		shareChangeReq.setUserId(preOrder.getUserId());
		shareChangeReq.setPlatformMerchantCode(TzPlatformMerchantCode.TZ_PLATFORM_MERCHANT_CODE);

		return shareChangeReq;
	}

	private boolean updatePreOrderStauts(String preOrderNo, Integer status, List<Integer> expectStatusList, Integer payStatus,
			String failReason,String remark) {
		PreOrderVo updatePreOrderVo = new PreOrderVo();
		updatePreOrderVo.setPreOrderNo(preOrderNo);
		updatePreOrderVo.setStatus(status);
		updatePreOrderVo.setExpectStatusList(expectStatusList);
		updatePreOrderVo.setPayStatus(payStatus);
		updatePreOrderVo.setFailReason(failReason);
		updatePreOrderVo.setModifyTime(new Date());
		updatePreOrderVo.setRemark(remark);

		return preOrderService.updateWithStatus(updatePreOrderVo);

	}

	private Order getOrderByPreOrderNo(String preOrderNo, String type, String seller) {
		Result<Order> queryOrderResult = orderQueryFacade.getOne(preOrderNo, type, seller);
		if (!queryOrderResult.isSuccess()) {
			throw new IllegalArgumentException("查询订单异常");
		}

		return queryOrderResult.getData();
	}

	/**
	 * 构建购买请求
	 * 
	 * @param preOrder
	 * @return
	 */
	private MatchTradeRequst composeBuyRequest(final PreOrder preOrder) {
		String preOrderNo = preOrder.getPreOrderNo();
		String userId = preOrder.getUserId();
		long productId = Long.valueOf(preOrder.getProductId());
		String type = OrderType.MATCH_PURCHASE;
		int payWay = preOrder.getPayWay();
		String platformMerchantCode = preOrder.getPlatformMerchantCode();
		String seller = Seller.TBJ_SELLER;
		String channelName = preOrder.getChannelName();
		String platform = preOrder.getPlatform();

		//检查卡券信息
        Coupon deductCoupon = null;
        Long deductCouponId = preOrder.getDeductCouponId();
        if(deductCouponId != null) {
            deductCoupon = couponComponent.checkAndGetCoupon(deductCouponId);
            if(deductCoupon == null) {
                throw new IllegalArgumentException("找不到对应卡券信息 卡券id："+deductCouponId);
            }
        }

        MatchTradeRequst request = new MatchTradeRequst();
		request.setSerialNo(preOrderNo);
		request.setUserId(userId);
		request.setOrderType(type);
		request.setSeller(seller);
		request.setSerialNo(preOrderNo);
		request.setUserId(userId);
		request.setPayWay(payWay);
		request.setProductId(productId);
		request.setOrderType(type);
		request.setPlatformMerchantCode(platformMerchantCode);
		request.setChannelName(channelName);
		request.setPlatform(platform);

		// 主订单信息
		BigDecimal amount = preOrder.getOriginalAmount();
		OrderDTO orderDto = new OrderDTO();
		request.setOrderDTO(orderDto);

        BigDecimal deductAmount = BigDecimal.ZERO;
		if(deductCoupon != null){
            deductAmount = deductCoupon.getFaceAmount();
        }

        BigDecimal realPayAmount = amount.subtract(deductAmount);
        if (realPayAmount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("抵扣券金额需小于预约购买金额");
        }

        orderDto.setAmount(amount);
        orderDto.setRealPayAmount(realPayAmount);
        orderDto.setCharges(BigDecimal.ZERO);
        orderDto.setCompensateAmount(deductAmount);
        orderDto.setDeductAmount(deductAmount);
        orderDto.setDeductCouponId(deductCouponId);//抵扣券ID
        orderDto.setCreateTime(preOrder.getCreateTime());

		// 子订单信息
		List<MatchResultDatas> matchResultList = this.getMatchResultList(preOrderNo,platformMerchantCode);
		if (matchResultList == null) {
			throw new IllegalArgumentException("找不到对应预约单号匹配结果");
		}

		List<OrderDetailDTO> orderDetailDtoList = new ArrayList<OrderDetailDTO>();
		request.setDetailDtoList(orderDetailDtoList);

		//是否能使用卡券
		boolean useDeduct = deductCoupon != null? true : false;

		for (MatchResultDatas matchResult : matchResultList) {
			OrderDetailDTO orderDetailDto = new OrderDetailDTO();
			orderDetailDtoList.add(orderDetailDto);

			orderDetailDto.setSubjectId(matchResult.getId());

            BigDecimal amount1 = matchResult.getAmount();
            if(useDeduct && amount1.compareTo(deductAmount) > 0){
                //可以使用卡券 且 子订单金额 大于卡券金额
                orderDetailDto.setAmount(amount1);
                orderDetailDto.setRealPayAmount(amount1.subtract(deductAmount));
                orderDetailDto.setCompensateAmount(BigDecimal.ZERO);
                orderDetailDto.setDeductAmount(deductAmount);
                orderDetailDto.setCharges(BigDecimal.ZERO);

                //代金券ID
                orderDetailDto.setDeductCouponId(deductCouponId);
                useDeduct = false;
            }else{
                // 金额
                orderDetailDto.setAmount(amount1);
                orderDetailDto.setRealPayAmount(amount1);
                orderDetailDto.setCompensateAmount(BigDecimal.ZERO);
                orderDetailDto.setDeductAmount(BigDecimal.ZERO);
                orderDetailDto.setCharges(BigDecimal.ZERO);
            }
		}

		//卡券没有用掉???  需要人工介入   目前 匹配规则  支持小于100的代金券份额
		if(useDeduct){
		    throw new IllegalStateException("子订单匹配不了这么大额的卡券啊，卡券id：" + deductCouponId + " ,预约单id："+preOrderNo);
        }

		return request;
	}

	List<MatchResultDatas> getMatchResultList(String preOrderNo,String platformMerchantCode) {
		MatchResultSo so = new MatchResultSo();
		so.setPreOrderNo(preOrderNo);
		so.setPlatformMerchantCode(platformMerchantCode);
		List<MatchResult> matchResultList= matchResultService.searchPosBySo(so);
		if(CollectionUtils.isEmpty(matchResultList)){
			return null;
		}
		
		
		//json to arraylist for subject
		String datas=matchResultList.get(0).getDatas();
		List<MatchResultDatas> resList=MatchResultUtil.strToMatchResultDataList(datas);
		return resList;
	}



	private String getProcesPreOrderKey(String preOrderNo) {
		return LOCK_KEY_FOR_PRE_ORDER + preOrderNo;
	}

	private String getLockKey() {
		return LOCK_KEY_FOR_JOB;
	}

}
