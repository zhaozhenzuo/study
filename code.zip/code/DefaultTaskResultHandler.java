package com.tongbanjie.tz.match.core.concurrent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 默认结果汇总处理类
 * 
 * @author shenxiu
 *
 */
public class DefaultTaskResultHandler implements QuickTaskResultHandler<BizTaskResult, ConsumeSumTaskResult> {

	private static final Logger logger = LoggerFactory.getLogger(DefaultTaskResultHandler.class);

	/**
	 * 最終結果集
	 */
	private ConsumeSumTaskResult consumeTaskResult = new ConsumeSumTaskResult();

	/**
	 * 为每个状态保留的信息列表数量
	 */
	private int MAX_INFO_SIZE_FOR_EACH_STATUS = 300;

	/**
	 * 当前info列表数量
	 */
	private AtomicInteger infoListSizeCount = new AtomicInteger(0);

	@Override
	public void handle(Future<BizTaskResult> future) {
		try {
			BizTaskResult res = future.get();
			List<String> infoList = null;
			if (StringUtils.isNotBlank(res.getInfo()) && infoListSizeCount.get() < MAX_INFO_SIZE_FOR_EACH_STATUS) {
				/**
				 * info不为空，则当前info列表数小于MAX_INFO_SIZE_FOR_EACH_STATUS，则放入info列表
				 */
				infoList = new ArrayList<String>();
				infoList.add(res.getInfo());
				infoListSizeCount.addAndGet(1);
			}
			consumeTaskResult.addElementOfStatus(res.getBizStatus(), res.getBizStatusDesc(), 1, infoList);
		} catch (InterruptedException e) {
			logger.error("InterruptedException", e);
		} catch (ExecutionException e) {
			logger.error("ExecutionException", e);
		} finally {
			consumeTaskResult.getAllCount().incrementAndGet();
		}

	}

	@Override
	public ConsumeSumTaskResult getResult() {
		return consumeTaskResult;
	}

}
