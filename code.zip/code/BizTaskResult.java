package com.tongbanjie.tz.match.core.concurrent;

import java.io.Serializable;

/**
 * 业务任务结果类<br/>
 * 
 * @author shenxiu
 *
 */
public class BizTaskResult implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 业务处理结果status，业务方自己定义 <br/>
	 * {@link com.tongbanjie.commons.constants.BizStatus}
	 */
	private Integer bizStatus;

	/**
	 * 业务处理结果状态描述
	 */
	private String bizStatusDesc;

	/**
	 * 业务处理后返回的结果，可以是错误原因，单号等，由业务方自己定义
	 */
	private String info;

	public BizTaskResult() {

	}

	public BizTaskResult(Integer bizStatus, String bizStatusDesc, String info) {
		this.bizStatus = bizStatus;
		this.bizStatusDesc = bizStatusDesc;
		this.info = info;
	}

	public Integer getBizStatus() {
		return bizStatus;
	}

	public void setBizStatus(Integer bizStatus) {
		this.bizStatus = bizStatus;
	}

	public String getBizStatusDesc() {
		return bizStatusDesc;
	}

	public void setBizStatusDesc(String bizStatusDesc) {
		this.bizStatusDesc = bizStatusDesc;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

}
