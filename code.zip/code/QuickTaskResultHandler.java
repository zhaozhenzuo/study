package com.tongbanjie.tz.match.core.concurrent;

import java.util.concurrent.Future;

public interface QuickTaskResultHandler<T, R> {

	public void handle(Future<T> future);

	public R getResult();

}
